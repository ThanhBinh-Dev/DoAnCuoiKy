class Time:
    def __init__(self,giokham):
        self.giokham=giokham
    def __str__(self):
        return f"{self.giokham}"