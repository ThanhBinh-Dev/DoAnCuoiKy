class DichVuKham:
    def __init__(self,dichvu):
        self.dichvu = dichvu
    def __str__(self):
        return f"{self.dichvu}"