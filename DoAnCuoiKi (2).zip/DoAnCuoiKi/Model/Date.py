class Date:
    def __init__(self,ngaykham):
        self.ngaykham=ngaykham
    def __str__(self):
        return f"{self.ngaykham}"